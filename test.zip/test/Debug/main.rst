                              1 ;--------------------------------------------------------
                              2 ; File Created by SDCC : FreeWare ANSI-C Compiler
                              3 ; Version 2.6.3 #4543 (Dec 31 2006)
                              4 ; This file generated Wed Apr 05 16:37:10 2017
                              5 ;--------------------------------------------------------
                              6 	.module ___main
                              7 	.optsdcc -mmcs51 --model-small
                              8 	
                              9 ;--------------------------------------------------------
                             10 ; Public variables in this module
                             11 ;--------------------------------------------------------
                             12 	.globl _main
                             13 	.globl _global_config_reg03
                             14 	.globl _global_config_reg02
                             15 	.globl _global_config_reg01
                             16 	.globl _global_config_reg00
                             17 	.globl _gpio_in
                             18 	.globl _gpio_out
                             19 	.globl _outreg
                             20 	.globl _inreg
                             21 ;--------------------------------------------------------
                             22 ; special function registers
                             23 ;--------------------------------------------------------
                             24 	.area RSEG    (DATA)
                             25 ;--------------------------------------------------------
                             26 ; special function bits
                             27 ;--------------------------------------------------------
                             28 	.area RSEG    (DATA)
                             29 ;--------------------------------------------------------
                             30 ; overlayable register banks
                             31 ;--------------------------------------------------------
                             32 	.area REG_BANK_0	(REL,OVR,DATA)
   0000                      33 	.ds 8
                             34 ;--------------------------------------------------------
                             35 ; internal ram data
                             36 ;--------------------------------------------------------
                             37 	.area DSEG    (DATA)
                    0000     38 G$inreg$0$0==.
   0018                      39 _inreg::
   0018                      40 	.ds 1
                    0001     41 G$outreg$0$0==.
   0019                      42 _outreg::
   0019                      43 	.ds 1
                    0002     44 Lmain$a$1$1==.
   001A                      45 _main_a_1_1:
   001A                      46 	.ds 2
                    0004     47 Lmain$config_reg01$1$1==.
   001C                      48 _main_config_reg01_1_1:
   001C                      49 	.ds 2
                             50 ;--------------------------------------------------------
                             51 ; overlayable items in internal ram 
                             52 ;--------------------------------------------------------
                             53 	.area OSEG    (OVR,DATA)
                             54 ;--------------------------------------------------------
                             55 ; Stack segment in internal ram 
                             56 ;--------------------------------------------------------
                             57 	.area	SSEG	(DATA)
   001E                      58 __start__stack:
   001E                      59 	.ds	1
                             60 
                             61 ;--------------------------------------------------------
                             62 ; indirectly addressable internal ram data
                             63 ;--------------------------------------------------------
                             64 	.area ISEG    (DATA)
                             65 ;--------------------------------------------------------
                             66 ; absolute internal ram data
                             67 ;--------------------------------------------------------
                             68 	.area IABS    (ABS,DATA)
                             69 	.area IABS    (ABS,DATA)
                             70 ;--------------------------------------------------------
                             71 ; bit data
                             72 ;--------------------------------------------------------
                             73 	.area BSEG    (BIT)
                             74 ;--------------------------------------------------------
                             75 ; paged external ram data
                             76 ;--------------------------------------------------------
                             77 	.area PSEG    (PAG,XDATA)
                             78 ;--------------------------------------------------------
                             79 ; external ram data
                             80 ;--------------------------------------------------------
                             81 	.area XSEG    (XDATA)
                    F0A0     82 G$gpio_out$0$0 == 0xf0a0
                    F0A0     83 _gpio_out	=	0xf0a0
                    F090     84 G$gpio_in$0$0 == 0xf090
                    F090     85 _gpio_in	=	0xf090
                    F000     86 G$global_config_reg00$0$0 == 0xf000
                    F000     87 _global_config_reg00	=	0xf000
                    F004     88 G$global_config_reg01$0$0 == 0xf004
                    F004     89 _global_config_reg01	=	0xf004
                    F008     90 G$global_config_reg02$0$0 == 0xf008
                    F008     91 _global_config_reg02	=	0xf008
                    F000     92 G$global_config_reg03$0$0 == 0xf000
                    F000     93 _global_config_reg03	=	0xf000
                             94 ;--------------------------------------------------------
                             95 ; external initialized ram data
                             96 ;--------------------------------------------------------
                             97 	.area XISEG   (XDATA)
                             98 	.area HOME    (CODE)
                             99 	.area GSINIT0 (CODE)
                            100 	.area GSINIT1 (CODE)
                            101 	.area GSINIT2 (CODE)
                            102 	.area GSINIT3 (CODE)
                            103 	.area GSINIT4 (CODE)
                            104 	.area GSINIT5 (CODE)
                            105 	.area GSINIT  (CODE)
                            106 	.area GSFINAL (CODE)
                            107 	.area CSEG    (CODE)
                            108 ;--------------------------------------------------------
                            109 ; interrupt vector 
                            110 ;--------------------------------------------------------
                            111 	.area HOME    (CODE)
   0000                     112 __interrupt_vect:
   0000 02 00 08            113 	ljmp	__sdcc_gsinit_startup
                            114 ;--------------------------------------------------------
                            115 ; global & static initialisations
                            116 ;--------------------------------------------------------
                            117 	.area HOME    (CODE)
                            118 	.area GSINIT  (CODE)
                            119 	.area GSFINAL (CODE)
                            120 	.area GSINIT  (CODE)
                            121 	.globl __sdcc_gsinit_startup
                            122 	.globl __sdcc_program_startup
                            123 	.globl __start__stack
                            124 	.globl __mcs51_genXINIT
                            125 	.globl __mcs51_genXRAMCLEAR
                            126 	.globl __mcs51_genRAMCLEAR
                            127 	.area GSFINAL (CODE)
   005F 02 00 03            128 	ljmp	__sdcc_program_startup
                            129 ;--------------------------------------------------------
                            130 ; Home
                            131 ;--------------------------------------------------------
                            132 	.area HOME    (CODE)
                            133 	.area HOME    (CODE)
   0003                     134 __sdcc_program_startup:
   0003 12 00 62            135 	lcall	_main
                            136 ;	return from main will lock up
   0006 80 FE               137 	sjmp .
                            138 ;--------------------------------------------------------
                            139 ; code
                            140 ;--------------------------------------------------------
                            141 	.area CSEG    (CODE)
                            142 ;------------------------------------------------------------
                            143 ;Allocation info for local variables in function 'main'
                            144 ;------------------------------------------------------------
                            145 ;a                         Allocated with name '_main_a_1_1'
                            146 ;config_reg01              Allocated with name '_main_config_reg01_1_1'
                            147 ;------------------------------------------------------------
                    0000    148 	G$main$0$0 ==.
                    0000    149 	C$main.c$23$0$0 ==.
                            150 ;	../main.c:23: void main(){
                            151 ;	-----------------------------------------
                            152 ;	 function main
                            153 ;	-----------------------------------------
   0062                     154 _main:
                    0002    155 	ar2 = 0x02
                    0003    156 	ar3 = 0x03
                    0004    157 	ar4 = 0x04
                    0005    158 	ar5 = 0x05
                    0006    159 	ar6 = 0x06
                    0007    160 	ar7 = 0x07
                    0000    161 	ar0 = 0x00
                    0001    162 	ar1 = 0x01
                    0000    163 	C$main.c$26$1$1 ==.
                            164 ;	../main.c:26: outreg = 0x00;
                            165 ;	genAssign
   0062 75 19 00            166 	mov	_outreg,#0x00
                    0003    167 	C$main.c$27$1$1 ==.
                            168 ;	../main.c:27: inreg = 0x00;
                            169 ;	genAssign
   0065 75 18 00            170 	mov	_inreg,#0x00
                    0006    171 	C$main.c$28$1$1 ==.
                            172 ;	../main.c:28: config_reg01 = global_config_reg01;
                            173 ;	genAssign
   0068 90 F0 04            174 	mov	dptr,#_global_config_reg01
   006B E0                  175 	movx	a,@dptr
   006C FA                  176 	mov	r2,a
                            177 ;	genCast
   006D 8A 1C               178 	mov	_main_config_reg01_1_1,r2
   006F 75 1D 00            179 	mov	(_main_config_reg01_1_1 + 1),#0x00
                    0010    180 	C$main.c$29$1$1 ==.
                            181 ;	../main.c:29: global_config_reg01 = 0x03;
                            182 ;	genAssign
   0072 90 F0 04            183 	mov	dptr,#_global_config_reg01
   0075 74 03               184 	mov	a,#0x03
   0077 F0                  185 	movx	@dptr,a
                    0016    186 	C$main.c$30$1$1 ==.
                            187 ;	../main.c:30: global_config_reg00 = 0x03;
                            188 ;	genAssign
   0078 90 F0 00            189 	mov	dptr,#_global_config_reg00
   007B 74 03               190 	mov	a,#0x03
   007D F0                  191 	movx	@dptr,a
                    001C    192 	C$main.c$31$1$1 ==.
                            193 ;	../main.c:31: global_config_reg02 = 0x03;
                            194 ;	genAssign
   007E 90 F0 08            195 	mov	dptr,#_global_config_reg02
   0081 74 03               196 	mov	a,#0x03
   0083 F0                  197 	movx	@dptr,a
                    0022    198 	C$main.c$32$1$1 ==.
                            199 ;	../main.c:32: global_config_reg03 = 0x03;
                            200 ;	genAssign
   0084 90 F0 00            201 	mov	dptr,#_global_config_reg03
   0087 74 03               202 	mov	a,#0x03
   0089 F0                  203 	movx	@dptr,a
                    0028    204 	C$main.c$33$1$1 ==.
                            205 ;	../main.c:33: a = 1;
                            206 ;	genAssign
   008A 75 1A 01            207 	mov	_main_a_1_1,#0x01
   008D E4                  208 	clr	a
   008E F5 1B               209 	mov	(_main_a_1_1 + 1),a
   0090                     210 00102$:
                    002E    211 	C$main.c$35$2$2 ==.
                            212 ;	../main.c:35: a++;
                            213 ;	genPlus
                            214 ;	genPlusIncr
   0090 74 01               215 	mov	a,#0x01
   0092 25 1A               216 	add	a,_main_a_1_1
   0094 F5 1A               217 	mov	_main_a_1_1,a
   0096 74 00               218 	mov	a,#0x00
   0098 35 1B               219 	addc	a,(_main_a_1_1 + 1)
   009A F5 1B               220 	mov	(_main_a_1_1 + 1),a
                    003A    221 	C$main.c$36$2$2 ==.
                            222 ;	../main.c:36: inreg = gpio_in;
                            223 ;	genAssign
   009C 90 F0 90            224 	mov	dptr,#_gpio_in
   009F E0                  225 	movx	a,@dptr
   00A0 F5 18               226 	mov	_inreg,a
   00A2 02 00 90            227 	ljmp	00102$
   00A5                     228 00104$:
                    0043    229 	C$main.c$38$2$2 ==.
                    0043    230 	XG$main$0$0 ==.
   00A5 22                  231 	ret
                            232 	.area CSEG    (CODE)
                            233 	.area CONST   (CODE)
                            234 	.area XINIT   (CODE)
                            235 	.area CABS    (ABS,CODE)
